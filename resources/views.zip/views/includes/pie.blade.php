<footer class="footer">
    <p>© 2025 Sistema de Gestión del Dojo</p>
</footer>