<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Menú Navegación</title>

  <link rel="stylesheet" href="css/estilo2.css">
  <link rel="stylesheet" href="css/menu.css">

  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>

<nav>
  <ul>
    <li>
      <a href="principal.html" title="Inicio">
        <i class="bi bi-house-door"></i>
      </a>
    </li>

    <li>
      <a href="usuarios.html" title="Usuarios">
        <i class="bi bi-people"></i>
      </a>
    </li>

    <li>
      <a href="alumno.html" title="Alumno">
        <i class="bi bi-person-badge"></i>
      </a>
    </li>

    <li>
      <a href="tutor.html" title="Tutor">
        <i class="bi bi-person-lines-fill"></i>
      </a>
    </li>

    <li>
      <a href="pagos.html" title="Pagos">
        <i class="bi bi-cash-coin"></i>
      </a>
    </li>

    <li>
      <a href="cintas.html" title="Cintas">
        <i class="bi bi-award"></i>
      </a>
    </li>

    <li>
      <a href="../" title="Salir">
        <i class="bi bi-box-arrow-right"></i>
      </a>
    </li>
  </ul>
</nav>

</body>
</html>
