<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Gestión de Pagos</title>

  <!-- CSS separado -->
  <link rel="stylesheet" href="/public/css/estilo6.css">
  <!--<link rel="stylesheet" href="css/pagos.css"> -->

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>

  <!-- Menú -->
  <?php include("include/menu.php"); ?>

  <div class="main-content">
    <header>
      <h1 class="text-center">Gestión de Pagos</h1>
    </header>

    <div class="content">
      <form id="registroPago" method="post" action="../servidor/insertarPago.php">
        <h2 class="text-center">Registrar Pago</h2>

        <select name="id_alumno" required>
          <option value="">Seleccione Alumno</option>
          <!-- PHP dinámico -->
          <?php while($a = $alumnos->fetch_assoc()): ?>
            <option value="<?= $a['id_alumno'] ?>"><?= htmlspecialchars($a['nombre']) ?></option>
          <?php endwhile; ?>
        </select>

        <select name="id_TipoPago" required>
          <option value="">Seleccione Tipo de Pago</option>
          <option value="1">Efectivo</option>
          <option value="2">Tarjeta</option>
        </select>

        <input type="number" name="monto" step="0.01" placeholder="Monto" required>

        <select name="motivoPago" required>
          <option value="">Seleccione motivo de pago</option>
          <option value="mensualidad">Mensualidad</option>
          <option value="seminario">Seminario</option>
          <option value="examen">Examen</option>
          <option value="abono">Abono</option>
          <option value="otro">Otro</option>
        </select>

        <input type="date" name="fechaPago" required>
        <input type="text" name="referenciaPago" placeholder="Referencia (opcional)">

        <select name="estadoPago" required>
          <option value="">Seleccione Estado</option>
          <option value="pendiente">Pendiente</option>
          <option value="pagado">Pagado</option>
          <option value="cancelado">Cancelado</option>
        </select>

        <button type="submit" class="btn btn-primary mt-3">Registrar Pago</button>
      </form>

      <!-- Tabla -->
      <div class="table-responsive tabla-pagos">
        <h2 class="text-center mt-4 mb-4">Pagos Registrados</h2>

        <table class="table table-striped table-hover align-middle tabla-estilizada">
          <thead class="table-dark">
            <tr>
              <th>Alumno</th>
              <th>Tipo de Pago</th>
              <th>Monto</th>
              <th>Fecha</th>
              <th>Motivo</th>
              <th>Referencia</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($p = $resPagos->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($p['alumno']) ?></td>
              <td><?= htmlspecialchars($p['tipo']) ?></td>
              <td>$<?= number_format($p['monto'], 2) ?></td>
              <td><?= htmlspecialchars($p['fechaPago']) ?></td>
              <td><?= htmlspecialchars($p['motivoPago']) ?></td>
              <td><?= htmlspecialchars($p['referenciaPago']) ?></td>
              <td><?= htmlspecialchars($p['estadoPago']) ?></td>
              <td>
                <button 
                  class="btn btn-sm btn-warning"
                  title="Editar"
                  data-bs-toggle="modal"
                  data-bs-target="#modalEditarPago"
                >
                  <i class="bi bi-pencil-square"></i>
                </button>

                <button 
                  class="btn btn-sm btn-danger"
                  title="Eliminar"
                >
                  <i class="bi bi-trash"></i>
                </button>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php include("include/pie.php"); ?>
  </div>

  <!-- Bootstrap y JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <!-- Script propio -->
  <script src="js/pagos.js"></script>

</body>
</html>
